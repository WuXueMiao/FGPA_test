`define sg25E 
